export const HOST = "http://localhost:8080";

export const LEAVE_API = `${HOST}/leave`;
export const LEAVES_API = `${HOST}/leaves`;
export const LEAVE_ID_API = (id) =>`${HOST}/leave/${id}`;
export const LEAVE_STATUS_API = (id,leavestatus) =>`${HOST}/leave/${id}/${leavestatus}`;

