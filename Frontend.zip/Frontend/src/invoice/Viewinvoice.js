import React, { useEffect, useState } from 'react'

import axios from "axios"

export default function Viewinvoice() {

  const [invoices,setInvoice]=useState([]);

    useEffect(()=>{
       loadInvoice();
    },[]);

    const loadInvoice=async()=>{
      const result=await axios.get("http://localhost:8080/invoices")
      setInvoice(result.data);
    }

    const deleteInvoice = async (id) => {
      const userChoice = window.prompt(
        "Select an option to delete this invoice:\n\n1. Delete from Database\n2. Delete from Page Only\n",
        "1"
      );
    
      if (userChoice === "1") {
        const confirmDelete = window.confirm("Are you sure you want to delete this invoice from the database?");
        if (confirmDelete) {
          try {
            await axios.delete(`http://localhost:8080/invoice/${id}`);
            loadInvoice();
          } catch (error) {
            console.error("Error deleting invoice:", error);
          }
        }
      } else if (userChoice === "2") {
        setInvoice((prevInvoices) =>
          prevInvoices.filter((invoice) => invoice.id !== id)
        );
      } else {
        // Cancel deletion
        return;
      }
    };
    
    


  return (
    <div> <h2 className="text-center m-4">ALL INVOICES</h2>
    <div className= "container">
        <div className="py-4">
        <table className="table border shadow">
  <thead>
    <tr>
      <th scope="col">Invoice ID</th>
      <th scope="col">Customer ID</th>
      <th scope="col">Created Date</th>
      <th scope="col">Due Date</th>
      <th scope="col" className="text-end">Total(Rs.)</th>
      <th scope="col" className="text-end">Discount(Rs.)</th>
      <th scope="col" className="text-end">Net Amount(Rs.)</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  {invoices.map((invoice) => (
      <tr>
      <th> {invoice.id}</th>
      <td>{invoice.ownerid}  </td>
      <td>{invoice.createddate} </td>
      <td>{invoice.duedate}</td>
      <td className="text-end">{invoice.total.toFixed(2)}</td>
      <td className="text-end">{invoice.discount.toFixed(2)}</td>
      <td className="text-end">{invoice.netamount.toFixed(2)}</td>
      <td>
        
      
        <button className="btn btn-danger mx-1" onClick={()=>deleteInvoice(invoice.id)}>Delete</button>
     </td>
      </tr>
      ))}
    
  </tbody>
  
</table>
    </div>
    </div>
    </div>
    
  )
  
}
