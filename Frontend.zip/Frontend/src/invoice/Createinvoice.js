import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Createinvoice() {
  const [finalTotal, setFinalTotal] = useState(0);
  const [products, setProducts] = useState([]);
  const [itemlist, setItemlist] = useState({
    product: "",
    quantity: "",
  });
  const [selectedItems, setSelectedItems] = useState([]);
  const [invoice, setInvoice] = useState({
    ownerid: "",
    createddate: "",
    duedate: "",
  });
  const [errors, setErrors] = useState({});

  useEffect(() => {
    fetchItems();
  }, []);

  const fetchItems = async () => {
    try {
      const response = await axios.get("http://localhost:8080/products");
      setProducts(response.data);
    } catch (error) {
      console.error("Error fetching items:", error);
    }
  };

  const { product, quantity } = itemlist;

  const onItemChange = (e) => {
    setItemlist({ ...itemlist, [e.target.name]: e.target.value });
  };

  const onAdd = (e) => {
    e.preventDefault();
    if (!product || !quantity) {
      setErrors({ ...errors, itemError: "Please select an item and enter the quantity" });
      return;
    }
  
    const selectedProduct = products.find((item) => item.productname === product);
  
    if (parseInt(quantity) <= 0) {
      setErrors({ ...errors, quantityError: "Please enter a valid quantity" });
      return;
    }
  
    let newItem = null;
  
    // Check if the selected item already exists in the selectedItems list
    const existingItem = selectedItems.find((item) => item.productid === selectedProduct.id);
  
    if (existingItem) {
      // Update the existing item with the new quantity and total
      existingItem.quantity += parseInt(quantity);
      existingItem.total = existingItem.quantity * selectedProduct.unitprice;
    } else {
      // Add a new item to the selectedItems list
      newItem = {
        productid: selectedProduct.id,
        productname: selectedProduct.productname,
        quantity: parseInt(quantity),
        unitprice: selectedProduct.unitprice,
        total: parseInt(quantity) * selectedProduct.unitprice,
      };
      setSelectedItems([...selectedItems, newItem]);
    }
  
    setItemlist({ product: "", quantity: "" });
    setErrors({});
    
    // Calculate the total amount after adding the new item
    const updatedItems = newItem ? [...selectedItems, newItem] : selectedItems;
    const totalamount = calculateTotal(updatedItems);
    setFinalTotal(Number(totalamount.total));
  };
  
  
  const calculateTotal = (items) => {
    let total = 0;
    for (let item of items) {
      total += item.total;
    }

    let discount = 0;
    if (total > 5000) {
      discount = total * 0.05;
    }

    let netamount = total - discount;

    return {
      total: total.toFixed(2),
      discount: discount.toFixed(2),
      netamount: netamount.toFixed(2),
    };
  };

  let navigate = useNavigate();

  const onInputChange = (e) => {
    setInvoice({ ...invoice, [e.target.name]: e.target.value });
  };

  const validateForm = () => {
    let isValid = true;
    const errors = {};

    if (!invoice.ownerid || invoice.ownerid.trim() === "" || parseInt(invoice.ownerid) <= 0) {
      errors.owneridError = "Please enter a valid customer ID";
      isValid = false;
    }

    if (!invoice.createddate || !invoice.duedate) {
      errors.dateError = "Please enter both the created date and due date";
      isValid = false;
    } else if (invoice.createddate > invoice.duedate) {
      errors.dateError = "Due date should be greater than the created date";
      isValid = false;
    }

    if (finalTotal === 0) {
      errors.totalError = "Please select items to create an invoice";
      isValid = false;
    }

    setErrors(errors);
    return isValid;
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) {
      return;
    }

    const invoiceData = {
      ...invoice,
      total: finalTotal,
      discount: calculateTotal(selectedItems).discount,
      netamount: calculateTotal(selectedItems).netamount,
    };

    try {
      await axios.post("http://localhost:8080/invoice", invoiceData);
      navigate("/");
    } catch (error) {
      console.error("Error creating invoice:", error);
    }
  };

  const onDelete = (index) => {
    const updatedItems = [...selectedItems];
    updatedItems.splice(index, 1);
    setSelectedItems(updatedItems);
    const totalAmount = calculateTotal(updatedItems);
    setFinalTotal(Number(totalAmount.total));
  };

  return (
    <div>
      <h2 className="text-center m-4">CREATE INVOICE</h2>
      <div className="container">
        <div className="row">
          <div className="col-md-6 offset-md-3 border rounded p-4 mt-2 shadow">
            <form className="row g-3" onSubmit={onSubmit}>
              <div className="col-12">
                <h4 className="text-left m-8">Details</h4>
                <hr />
              </div>

              <div className="col-md-8">
                <label htmlFor="OwnerId" className="form-label">
                  Customer ID
                </label>
                <input
                  type={"text"}
                  className="form-control"
                  placeholder="Enter customer ID"
                  name="ownerid"
                  required
                  value={invoice.ownerid}
                  onChange={onInputChange}
                />
                {errors.owneridError && (
                  <div className="text-danger">{errors.owneridError}</div>
                )}
              </div>

              <div className="col-md-6">
                <label htmlFor="Create Date" className="form-label">
                  Created Date
                </label>
                <div className="mb-3">
                  <input
                    className="form-control"
                    type="date"
                    required
                    name="createddate"
                    value={invoice.createddate}
                    onChange={onInputChange}
                  />
                </div>
              </div>

              <div className="col-md-6">
                <label htmlFor="Due Date" className="form-label">
                  Due Date
                </label>
                <div className="mb-3">
                  <input
                    className="form-control"
                    type="date"
                    required
                    name="duedate"
                    value={invoice.duedate}
                    onChange={onInputChange}
                  />
                  {errors.dateError && (
                    <div className="text-danger">{errors.dateError}</div>
                  )}
                </div>
              </div>

              <div className="col-12">
                <h4 className="text-left m-8">Select Item</h4>
                <hr />
              </div>
              <div className="col-md-6">
                <label htmlFor="Product" className="form-label">
                  Product Name
                </label>
                <select
                  className="form-select"
                  aria-label="Default select example"
                  name="product"
                  value={product}
                  onChange={onItemChange}
                >
                  <option value="">-- Select Item --</option>
                  {products.map((item) => (
                    <option key={item.id} value={item.productname}>
                      {item.productname}
                    </option>
                  ))}
                </select>
              </div>
              <div className="col-md-6">
                <label htmlFor="Quantity" className="form-label">
                  Quantity
                </label>
                <input
                  type={"text"}
                  className="form-control"
                  name="quantity"
                  value={quantity}
                  onChange={onItemChange}
                />
                {errors.quantityError && (
                  <div className="text-danger">{errors.quantityError}</div>
                )}
              </div>
              <div className="col-12">
                <button
                  className="btn btn-success float-end"
                  onClick={onAdd}
                >
                  +Add Item
                </button>
              </div>
              <div className="col-12">
                <h4 className="text-left m-8">Product List</h4>
                <hr />
                <table className="table border shadow">
                  <thead>
                    <tr>
                      <th scope="col">Item</th>
                      <th scope="col">Quantity</th>
                      <th scope="col">Unit Price</th>
                      <th scope="col">Total</th>
                      <th scope="col">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {selectedItems.map((item, index) => (
                      <tr key={item.productid}>
                        <td>{item.productname}</td>
                        <td>{item.quantity}</td>
                        <td>{item.unitprice.toFixed(2)}</td>
                        <td>{item.total.toFixed(2)}</td>
                        <td>
                          <button
                            className="btn btn-danger btn-sm"
                            onClick={() => onDelete(index)}
                          >
                            Delete
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="col-12">
                <h4 className="text-left m-8">Amount</h4>
                <hr />
                <div className="row mb-3">
                  <label htmlFor="Total" className="col-sm-3 col-form-label">
                    Total:
                  </label>
                  <div className="col-sm-5 d-flex align-items-center">
                    <input
                      type="text"
                      className="form-control text-end"
                      name="total"
                      value={`Rs. ${calculateTotal(selectedItems).total}`}
                      readOnly
                    />
                  </div>
                </div>

                <div className="row mb-3">
                  <label
                    htmlFor="Discount"
                    className="col-sm-3 col-form-label"
                  >
                    Discount:
                  </label>
                  <div className="col-sm-5 d-flex align-items-center">
                    <input
                      type="text"
                      className="form-control text-end"
                      name="total"
                      value={`Rs. ${calculateTotal(selectedItems).discount}`}
                      readOnly
                    />
                  </div>
                </div>

                <div className="row mb-3">
                  <label
                    htmlFor="Netammount"
                    className="col-sm-3 col-form-label"
                  >
                    Net Amount:
                  </label>
                  <div className="col-sm-5 d-flex align-items-center">
                    <input
                      type="text"
                      className="form-control text-end"
                      name="total"
                      value={`Rs. ${calculateTotal(selectedItems).netamount}`}
                      readOnly
                    />
                  </div>
                </div>

                <div className="col-12 d-flex justify-content-center">
                  <button
                    type="submit"
                    className="btn btn-primary col-8"
                    disabled={finalTotal === 0}
                  >
                    Create Invoice
                  </button>
                  {errors.totalError && (
                    <div className="text-danger">{errors.totalError}</div>
                  )}
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}


