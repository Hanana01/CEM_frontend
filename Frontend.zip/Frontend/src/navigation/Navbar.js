import React from 'react'
import { Link } from "react-router-dom";


export default function Navbar() {
  return (
    <div>
        <nav className="navbar navbar-expand-lg" style={{backgroundColor:"#000036"}}>
        <div className="container-fluid ">
        <h4  className="navbar-brand text-white" > Cutomer Employee Management</h4>
    
       <div className="collapse navbar-collapse justify-content-left">
        <div className="navbar-nav">
        <Link className="nav-link text-white" to="/leaveview"> View Leave </Link>
        <Link className="nav-link active text-white" to="/leavehistory"> Leave History</Link>
        
        <Link className="nav-link text-white" to="/apply"> Apply Leave</Link>
        <Link className="nav-link text-white" to="/invoice">Create Invoice</Link>
        <Link className="nav-link text-white" to="/viewinvoice"> View Invoice </Link>
        
      </div>
    </div>
  
  </div>
</nav>
    </div>
  )
}
