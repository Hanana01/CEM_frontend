import axios from "axios";
import React, { useState, useEffect } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";

export default function EditLeave() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [errors, setErrors] = useState({});
  const [leave, setLeave] = useState({
    eid: "",
    leavetype: "",
    startdate: "",
    enddate: "",
    leavestatus: "PENDING",
  });

  useEffect(() => {
    const fetchLeaveData = async () => {
      try {
        const response = await axios.get(`http://localhost:8080/leave/${id}`);
        const leaveData = response.data;
        setLeave(leaveData);
      } catch (error) {
        console.error("Error:", error);
      }
    };

    fetchLeaveData();
  }, [id]);

  const validate = () => {
    
    const errors = {};
  
    const date1 = new Date(startdate);
    const date2 = new Date(enddate);
  
    if (leave.eid <= 0) {
      errors.eid = "Please enter a valid employee ID";
    }
  
    if (leavetype === "HalfDay") {
      if (date1.getTime() !== date2.getTime()) {
        errors.enddate = "For half-day leave, the start and end dates should be the same";
      }
    } else {
      if (!(date1 <= date2)) {
        errors.enddate = "End date should be greater than start date";
      }
    }
  
    return errors;

  };

  const onInputChange = (e) => {
    setLeave({ ...leave, [e.target.name]: e.target.value });
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    const formErrors = validate();
    if (Object.keys(formErrors).length === 0) {
      try {
        await axios.put(`http://localhost:8080/leave/${id}`, leave);
        navigate("/");
        window.location.href = '/leavehistory';
      } catch (error) {
        console.error("Error:", error);
      }
    } else {
      setErrors(formErrors);
    }
  };

  const { eid, leavetype, startdate, enddate } = leave;
  

  return (
    <div>
     <h2 className="text-center m-4">LEAVE APPLICATION</h2>
      <div className="container">
        <div className="row">
          <div className="col-md-6 offset-md-3 border rounded p-4 mt-2 shadow">
            <form className="row g-3" onSubmit={onSubmit}>
              <div className="col-12">
                <h4 className="text-left m-8">Details</h4>
                <hr />
              </div>

              <div className="col-md-6">
                <label htmlFor="ID" className="form-label">
                  Employee ID
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Enter your ID no"
                  name="eid"
                  required
                  value={eid}
                  onChange={onInputChange}
                />
                {errors.eid && <span style={{ color: "red", fontSize: "10px" }}>{errors.eid}</span>}
              </div>

              <div className="col-md-6">
                <label htmlFor="Type" className="form-label">
                  Leave Type
                </label>
                <select
                  className="form-select"
                  aria-label="Default select example"
                  required
                  name="leavetype"
                  value={leavetype}
                  onChange={onInputChange}
                >
                  <option value="">--Select Leave Type--</option>
                  <option value="Medical">Medical</option>
                  <option value="Casual">Casual</option>
                  <option value="HalfDay">Half Day</option>
                </select>
              </div>

              <div className="col-md-6">
                <label htmlFor="Type" className="form-label">
                  Start Date
                </label>
                <div className="mb-3">
                  <input
                    className="form-control"
                    type="date"
                    required
                    name="startdate"
                    value={startdate}
                    onChange={onInputChange}
                  />
                </div>
              </div>

              <div className="col-md-6">
                <label htmlFor="Type" className="form-label">
                  End Date
                </label>
                <div className="mb-3">
                  <input
                    className="form-control"
                    type="date"
                    name="enddate"
                    required
                    value={enddate}
                    onChange={onInputChange}
                  />
                  {errors.enddate && <span style={{ color: "red", fontSize: "10px" }}>{errors.enddate}</span>}
                </div>
              </div>

              <div>
                <Link className="btn btn-danger mx-1 float-end" to="/leavehistory">
                  Cancel
                </Link>
                <button type="submit" className="btn btn-primary mx-3 float-end">
                  Apply
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
