import axios from "axios";
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { differenceInCalendarDays, addDays, isWeekend } from 'date-fns';


export default function ApplyLeave() {
  let navigate = useNavigate();

  
  const [errors, setErrors] = useState({});

  const [cemleave, setLeave] = useState({
    eid: "",
    leavetype: "",
    startdate: "",
    enddate: "",
    leavestatus: "PENDING",
    noOfDays: 0,
    

  });

 

  const validate = () => {
    const errors = {};
  
    if (cemleave.eid === "" || cemleave.eid <= 0) {
      errors.eid = "Please enter a valid employee ID";
    }

    const date1 = new Date(startdate);
    const date2 = new Date(enddate);
  
    if (leavetype === "HalfDay") {
      if (date1.getTime() !== date2.getTime()) {
        errors.enddate = "For half-day leave, the start and end dates should be the same";
      }
    } else {
      if (!(date1 <= date2)) {
        errors.enddate = "End date should be greater than start date";
      }
    }
  
    return errors;
  };
  

  const { eid, leavetype, startdate, enddate } = cemleave;

  const onInputChange = (e) => {
    setLeave({ ...cemleave, [e.target.name]: e.target.value });
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    const formErrors = validate();
    if (Object.keys(formErrors).length === 0) {
      const days = differenceInCalendarDays(new Date(enddate), new Date(startdate)) + 1;
      let count = 0;
      for (let i = 0; i < days; i++) {
        const currentDate = addDays(new Date(startdate), i);
        if (!isWeekend(currentDate)) {
          count++;
        }
      }
      cemleave.noOfDays = count;
  
      await axios.post('http://localhost:8080/leave', cemleave);
      navigate('/');
      window.location.href = '/leavehistory';
    } else {
      setErrors(formErrors);
    }
  };
  

  


  return (
    <div><h2 className="text-center m-4"> LEAVE APPLICATION</h2>
      <div className="container">
        <div className="row">
          <div className="col-md-6 offset-md-3 border rounded p-4 mt-2 shadow">


            <form class="row g-3" onSubmit={(e) => onSubmit(e)}>


              <div class="col-12">
                <h4 className="text-left m-8"> Details</h4>
                <hr />
              </div>

                <div className="col-md-6">
                <label htmlFor="ID" className="form-label">
                  Employee ID
                </label>
                <input
                  type={"text"}
                  className="form-control"
                  placeholder="Enter your ID no"
                  name="eid"
                  required
                  value={eid}
                  onChange={(e) => onInputChange(e)}
                />
                {errors.eid && <span style={{ color: "red", font: "10px" }}>{errors.eid}</span>}
              </div>



              <div className="col-md-6">
                <label htmlFor="Type" className="form-label">
                  Leave Type
                </label>
                <select className="form-select" aria-label="Default select example" required name="leavetype" value={leavetype}
                  onChange={(e) => onInputChange(e)} >

                  <option value="">--Select Leave Type--</option>
                  <option value="Medical">Medical</option>
                  <option value="Casual">Casual</option>
                  <option value="HalfDay">Half Day</option>
                </select>
              </div>

              <div className="col-md-6">
                <label htmlFor="Type" className="form-label">
                  Start Date
                </label>
                <div className="mb-3">
                  <input className="form-control"
                    type="date"
                    required
                    name="startdate"
                    value={startdate}
                    onChange={(e) => onInputChange(e)}
                  />
                </div>
              </div>

              <div className="col-md-6">
                <label htmlFor="Type" className="form-label">
                  End Date
                </label>
                <div className="mb-3">
                  <input className="form-control" type="date"
                    name="enddate"
                    required
                    value={enddate}
                    onChange={(e) => onInputChange(e)}
                  />

                  {errors.enddate && <span style={{ color: "red", font: "10px" }}>{errors.enddate}</span>}

                </div>
              </div>

              <div>
                <Link className="btn btn-danger mx-1 float-end" to="/leavehistory">
                  Cancel
                </Link>
                <button type="submit" className="btn btn-primary mx-3 float-end" >
                  Apply
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>

  );
}
