import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

export default function LeaveHistory() {
  const [leaves, setLeave] = useState([]);

  useEffect(() => {
    loadLeave();
  }, []);

  const loadLeave = async () => {
    const result = await axios.get('http://localhost:8080/leaves');
    setLeave(result.data);
  };

  const deleteLeave = async (id) => {
    const confirmDelete = window.confirm('Are you sure you want to delete this leave?');
    if (confirmDelete) {
      await axios.delete(`http://localhost:8080/leave/${id}`);
      loadLeave();
    }
  };


  const getLeaveStatusColor = (leavestatus) => {
    let colorClass = '';

    switch (leavestatus) {
      case 'APPROVED':
        colorClass = 'text-success';
        break;
      case 'PENDING':
        colorClass = 'text-primary';
        break;
      case 'REJECTED':
        colorClass = 'text-danger';
        break;
      default:
        colorClass = '';
        break;
    }

    return colorClass;
  };

  return (
    <div>
      <h2 className="text-center m-4">LEAVE HISTORY</h2>
      <div className="container">
        <div className="py-4">
          <table className="table border shadow">
            <thead>
              <tr>
                <th scope="col">No.</th>
                <th scope="col">Employee ID</th>
                <th scope="col">Leave Type</th>
                <th scope="col">Start Date</th>
                <th scope="col">End Date</th>
                <th scope="col">Leave Status</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              {leaves.map((cemleave, index) => (
                <tr key={cemleave.id}>
                  <th scope="row">{index + 1}</th>
                  <td>{cemleave.eid}</td>
                  <td>{cemleave.leavetype}</td>
                  <td>{cemleave.startdate}</td>
                  <td>{cemleave.enddate}</td>
                  <td className={getLeaveStatusColor(cemleave.leavestatus)}>
                    {cemleave.leavestatus}
                  </td>
                  <td>
                    <Link
                      className={`btn btn-primary mx-1 ${
                        cemleave.leavestatus !== 'PENDING' ? 'disabled' : ''
                      }`}
                      to={`/editleave/${cemleave.id}`}
                    >
                      Edit
                    </Link>
                    <button
                      className={`btn btn-danger mx-1 ${
                        cemleave.leavestatus !== 'PENDING' ? 'disabled' : ''
                      }`}
                      onClick={() => deleteLeave(cemleave.id)}
                      disabled={cemleave.leavestatus !== 'PENDING'}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
