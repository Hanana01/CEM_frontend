import React, { useEffect, useState } from 'react'

import axios from "axios"


export default function ViewLeave() {
  

  const [leaves, setLeaves] = useState([]);

  useEffect(() => {
    loadLeave();
  }, []);

  const loadLeave = async () => {
    const result = await axios.get("http://localhost:8080/leaves")
    setLeaves(result.data);
    
  }

  const updateCemLeave = async (e, id) => {
    const leavestatus = e.target.value;
    await axios.put(`http://localhost:8080/leave/${id}/${leavestatus}`);
    loadLeave();
  }


  return (
    <div> <h2 className="text-center m-4">VIEW ALL LEAVES </h2>
      <div className="container">
        <div className="py-4">
          <table className="table border shadow">
            <thead>
              <tr>
                <th scope="col">No.</th>
             
                <th scope="col">Employee ID</th>
             
                <th scope="col">Leave Type</th>
                <th scope="col">Start Date</th>
                <th scope="col">End Date</th>
                <th scope="col">Days</th>
                <th scope="col">Leave Status</th>
                <th scope="col">Action</th>
             


              </tr>
            </thead>
            <tbody>
              {leaves.map((cemleave, index) => (
                <tr>
                  <th scope="row" key={index}> {index + 1}</th>
               
                
                  <td> {cemleave.eid} </td>
                
                  <td> {cemleave.leavetype} </td>
                  <td> {cemleave.startdate} </td>
                  <td> {cemleave.enddate}</td>
                  <td> {cemleave.noOfDays}</td>
                  <td className="text-primary"> {cemleave.leavestatus}</td>
                  <td>
                  <button className="btn btn-success mx-1" value="APPROVED" onClick={(e) => updateCemLeave(e,cemleave.id)} >Approve</button>
                  <button className="btn btn-danger mx-1" value="REJECTED" onClick={(e) => updateCemLeave(e,cemleave.id)} >Reject</button>

                  </td>

                </tr>

              ))}

            </tbody>
          </table>
        </div>
      </div>
     
    </div>


  )
}
