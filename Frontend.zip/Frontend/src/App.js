import "../node_modules/bootstrap/dist/css/bootstrap.min.css";

import Navbar from "./navigation/Navbar";
import LeaveHistory from "./leave/LeaveHistory";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import ApplyLeave from "./leave/ApplyLeave";
import Createinvoice from "./invoice/Createinvoice";
import Viewinvoice from "./invoice/Viewinvoice";
import EditLeave from "./leave/EditLeave";
import View from "./leave/View"




function App() {
  return (
    <div className="App">
      <Router>
        <Navbar/>
        
       
        <Routes>
         
          <Route exact path="/apply" element={<ApplyLeave/>} />
          <Route exact path="/invoice" element={<Createinvoice/>} />
          <Route exact path="/viewinvoice" element={<Viewinvoice/>} />
          <Route exact path="/leaveview" element ={<View/>} />
          <Route exact path="/leavehistory" element={<LeaveHistory/>} />
          <Route exact path="/editleave/:id" element={<EditLeave/>} />
         
          
        </Routes>
        </Router>

        
    </div>
  );
}

export default App;

